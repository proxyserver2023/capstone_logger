Install

```
pip install git+https://github.com/proxyserver2023/capstone_logger_proxyserver2023.git
```
